﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Einstean
{
    enum Nationality
    {
        English,
        Swede,
        Dane,
        Norweign,
        German,
        Unknown
    }

    enum Color
    {
        Red,
        Green,
        Yellow,
        Blue,
        White,
        Unknown
    }

    enum Pet
    {
        Dog,
        Bird,
        Cat,
        Horse,
        Fish,
        Unknown
    }

    enum Drink
    {
        Tea,
        Coffee,
        Milk,
        Bier,
        Water,
        Unknown
    }

    enum Smoke
    {
        Pallmall,
        Dunhill,
        Blend,
        BlueMaster,
        Prince,
        Unknown
    }

    enum Location
    {
        First,
        Second,
        Third,
        Fourth,
        Fifth,
        Unknown
    }
}
